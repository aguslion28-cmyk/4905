<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
class NewPasswordController extends Controller {
 public function create(Request $request): View { return view('auth.reset-password',['request'=>$request]); }
 public function store(Request $request): RedirectResponse { $request->validate(['token'=>['required'],'email'=>['required','email'],'password'=>['required','confirmed',Rules\Password::min(10)->mixedCase()->numbers()]]); $status=Password::reset($request->only('email','password','password_confirmation','token'),function($user) use($request){$user->forceFill(['password'=>$request->password,'remember_token'=>Str::random(60)])->save();event(new PasswordReset($user));}); return $status===Password::PASSWORD_RESET ? redirect()->route('login')->with('status','Password berhasil diubah. Silakan masuk.') : back()->withErrors(['email'=>'Tautan reset tidak valid atau telah kedaluwarsa.']); }
}
